using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Projectfile.Pages
{
    public class Tyrannosaurus_rexModel : PageModel
    {
        public void OnGet()
        {
        }
      
    }
}
