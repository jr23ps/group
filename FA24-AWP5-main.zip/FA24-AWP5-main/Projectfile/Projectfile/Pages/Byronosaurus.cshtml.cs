using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Projectfile.Pages
{
    public class ByronosaurusModel : PageModel
    {
        
        public void OnGet()
        {
        }
    }
}
