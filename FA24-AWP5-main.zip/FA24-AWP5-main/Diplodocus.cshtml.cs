using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace project.Pages
{

    public class DiplodocusModel : PageModel
    {
  
    }
}
